#ifndef PARSER_H
#define PARSER_H

void expr();
void term();
void factor();
void error();

void program();
void statement();
void comp();
void oper();
void var();
void numb();

extern int nextToken;
#endif
