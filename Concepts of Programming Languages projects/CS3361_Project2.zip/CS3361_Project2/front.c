/**
 * This the example lexical analyzer code in pages 173 - 177 of the
 * textbook,
 *
 * Sebesta, R. W. (2012). Concepts of Programming Languages.
 * Pearson, 10th edition.
 *
 */

/* front.c - a lexical analyzer system for simple arithmetic expressions */
#include "front.h"
#include "parser.h"
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 

/* Global Variable */
int nextToken;

/* Local Variables */
static int charClass;
static char lexeme[100];
static char nextChar;
static int lexLen;
static FILE *in_fp;

/* Local Function declarations */
static void addChar();
static void getChar();
static void getNonBlank();

/******************************************************/
// main driver

int main(int argc, char *argv[]) {
  // Check if a file was provided as a command-line argument
  if (argc < 2) {
    // No file provided
    printf("Error: No input file provided.\n");
    return 2;  // Exit with code 2
  }

  // Open the input data file and process its contents
  printf("DCooke Analyzer::R11683434\n\n");
  if ((in_fp = fopen(argv[1], "r")) == NULL) {
    // File does not exist
    printf("Error: Input file '%s' does not exist\n", argv[1]);
    return 3;  // Exit with code 3
  }
 else{ getChar();
 do{ 
 lex();
 statement();
} while (nextToken != EOF); 
    printf("Syntax Validated\n");
    fclose(in_fp);
return 0;  // Exit with code 0
  } 

}

 


/*****************************************************/
/* lookup - a function to lookup operators and parentheses and return the
 * token */
static int lookup(char ch) {
  switch (ch) {

  case '(':
    addChar();
    nextToken = LEFT_PAREN;
    getChar();
    break;

  case ')':
    addChar();
    nextToken = RIGHT_PAREN;
    getChar();
    break;

  case '+':
    addChar();
    getChar();
    if (nextChar == '+') {
      addChar();
      nextToken = INC_OP;
      getChar();
    } else {
      nextToken = ADD_OP;
    }
    break;

  case '-':
    addChar();
    getChar();
    if (nextChar == '-') {
      addChar();
      nextToken = DEC_OP;
    } else {
      nextToken = SUB_OP;
      getChar();
    }
    break;

  case '*':
    addChar();
    nextToken = MULT_OP;
    getChar();
    break;

  case '/':
    addChar();
    nextToken = DIV_OP;
    getChar();
    break;

  case '=':
    addChar();
    getChar();
    if (nextChar == '=') {
      addChar();
      nextToken = EQUAL_OP;
      getChar();
    } else {
      nextToken = ASSIGN_OP;
    }
    break;

  case '<':
    addChar();
    getChar();
    if (nextChar == '=') {
      addChar();
      nextToken = LEQUAL_OP;
      getChar();
    } else {
      nextToken = LESSER_OP;
    }
    break;

  case '>':
    addChar();
    getChar();
    if (nextChar == '=') {
      addChar();
      nextToken = GEQUAL_OP;
      getChar();
    } else {
      nextToken = GREATER_OP;
    }
    break;

  case '!':
    addChar();
    getChar();
    if (nextChar == '=') {
      addChar();
      nextToken = NEQUAL_OP;
      getChar();
    } else {
      nextToken = UNKNOWN;
    }
    break;

  case ';':
    addChar();
    nextToken = SEMICOLON_OP;
    getChar();
    break;

  case '{':
    addChar();
    nextToken = LEFT_CBRACE;
    getChar();
    break;

  case '}':
    addChar();
    nextToken = RIGHT_CBRACE;
    getChar();
    break;

  default:
    addChar();
    getChar();
    nextToken = UNKNOWN;

    break;
  }
  return nextToken;
}

// to print out name of token
const char *nameoftoken() {
  switch (nextToken) {
  case KEY_READ:
    return "KEY_READ";
  case KEY_WHILE:
    return "KEY_WHILE";
  case KEY_WRITE:
    return "KEY_WRITE";
  case KEY_DO:
    return "KEY_DO";
  case IDENT:
    return "IDENT";
  case INT_LIT:
    return "INT_LIT";
  case LEFT_PAREN:
    return "LEFT_PAREN";
  case RIGHT_PAREN:
    return "RIGHT_PAREN";
  case INC_OP:
    return "INC_OP";
  case ADD_OP:
    return "ADD_OP";
  case DEC_OP:
    return "DEC_OP";
  case SUB_OP:
    return "SUB_OP";
  case MULT_OP:
    return "MULT_OP";
  case DIV_OP:
    return "DIV_OP";
  case ASSIGN_OP:
    return "ASSIGN_OP";
  case EQUAL_OP:
    return "EQUAL_OP";
  case LESSER_OP:
    return "LESSER_OP";
  case GREATER_OP:
    return "GREATER_OP";
  case LEQUAL_OP:
    return "LEQUAL_OP";
  case GEQUAL_OP:
    return "GEQUAL_OP";
  case NEQUAL_OP:
    return "NEQUAL_OP";
  case SEMICOLON_OP:
    return "SEMICOLON";
  case LEFT_CBRACE:
    return "LEFT_CBRACE";
  case RIGHT_CBRACE:
    return "RIGHT_CBRACE";
  case EOF:
    return "EOF";
  default:
    return "UNKNOWN";
  }
}

/*****************************************************/
/* addChar - a function to add nextChar to lexeme */
static void addChar() {
  if (lexLen <= 98) {
    lexeme[lexLen++] = nextChar;
    lexeme[lexLen] = 0;
  } else {
    printf("Error - lexeme is too long \n");
  }
}

/*****************************************************/
/* getChar - a function to get the next character of input and determine its
 * character class */
static void getChar() {
  if ((nextChar = getc(in_fp)) != EOF) {
    if (isalpha(nextChar))
      charClass = LETTER;
    else if (isdigit(nextChar))
      charClass = DIGIT;
    else
      charClass = UNKNOWN;

  } else {
    charClass = EOF;
  }
}

/*****************************************************/
/* getNonBlank - a function to call getChar until it returns a non-whitespace
 * character */
static void getNonBlank() {
  while (isspace(nextChar))
    getChar();
}

/*****************************************************/
/* lex - a simple lexical analyzer for arithmetic expressions */
int lex() {

  lexLen = 0;
  getNonBlank();

  switch (charClass) {
  /* Parse identifiers */
  case LETTER:
    addChar();
    getChar();
    while (charClass == LETTER || charClass == DIGIT) {
      addChar();
      getChar();
    }

    if (strcmp(lexeme, "read") == 0) {
      nextToken = KEY_READ;
    } else if (strcmp(lexeme, "write") == 0) {
      nextToken = KEY_WRITE;
    } else if (strcmp(lexeme, "while") == 0) {
      nextToken = KEY_WHILE;
    } else if (strcmp(lexeme, "do") == 0) {
      nextToken = KEY_DO;
    } else
      nextToken = IDENT;

    break;

  /* Parse integer literals */
  case DIGIT:
    addChar();
    getChar();

    while (charClass == DIGIT) {
      addChar();
      getChar();
    }

    nextToken = INT_LIT;
    break;

  /* Parentheses and operators */
  case UNKNOWN:
    lookup(nextChar);
    break;
  /* EOF */
  case EOF:
    nextToken = EOF;
    lexeme[0] = 'E';
    lexeme[1] = 'O';
    lexeme[2] = 'F';
    lexeme[3] = 0;
    return nextToken;
  } /* End of switch */
 /* End of function lex */
  return nextToken;
}
